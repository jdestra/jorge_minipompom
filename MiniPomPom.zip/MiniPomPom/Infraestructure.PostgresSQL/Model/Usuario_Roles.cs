﻿using Domain.Entities;
using System;

namespace Infraestructure.PostgresSQL.Model
{
    public class Usuario_Roles
    {
        public Guid UsuarioId { get; set; }
        public virtual Usuario Usuario { get; set; }
        public string TipoRolId { get; set; }
        public virtual TipoRol TipoRol { get; set; }


    }
}
