﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infraestructure.PostgresSQL.EntityConfig
{
    public class BitacoraConfiguration : IEntityTypeConfiguration<Bitacora>
    {
        public void Configure(EntityTypeBuilder<Bitacora> builder)
        {
            builder.ToTable("Bitacoras");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.UsuarioId).IsRequired();
            builder.Property(c => c.Fecha).IsRequired();
            builder.Property(c => c.AccionRealizada).IsRequired();
        }
    }
}
