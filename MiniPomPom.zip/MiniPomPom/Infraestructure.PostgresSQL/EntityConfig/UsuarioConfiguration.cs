﻿using Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Infraestructure.PostgresSQL.EntityConfig
{
    public class UsuarioConfiguration : IEntityTypeConfiguration<Usuario>
    {
        public void Configure(EntityTypeBuilder<Usuario> builder)
        {
            builder.ToTable("Usuarios");
            builder.HasKey(c => c.Id);
            builder.Property(c => c.NombreUsuario).IsRequired();
            builder.Property(c => c.HashPassword).IsRequired();
            builder.Property(c => c.Salt).IsRequired();
            builder.Property(c => c.Activo).IsRequired();
            builder.Property(c => c.PersonaId).IsRequired(false);
            builder.Ignore(c => c.Roles);
        }
    }
}
