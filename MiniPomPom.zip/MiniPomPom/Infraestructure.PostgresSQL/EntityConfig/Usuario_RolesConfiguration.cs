﻿using System;
using System.Collections.Generic;
using System.Text;
using Domain.Entities;
using Infraestructure.PostgresSQL.Model;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;


namespace Infraestructure.PostgresSQL.EntityConfig
{
    public class Usuario_RolesConfiguration : IEntityTypeConfiguration<Usuario_Roles>
    {
        public void Configure(EntityTypeBuilder<Usuario_Roles> builder)
        {
            builder.ToTable("Usuarios_Roles");
            builder.HasKey(c => new { c.UsuarioId, c.TipoRolId});
        }
    }
}
