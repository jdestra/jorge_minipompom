﻿using Domain.Entities;
using Domain.Interfaces.Repositories;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infraestructure.PostgresSQL.Repositories
{
    public class BitacoraRepository : BaseRepository<Bitacora>, IBitacoraRepository
    {
        public void AddBitacora(Bitacora bitacora)
        {
            db.Bitacora.Add(bitacora);
        }
    }
}
