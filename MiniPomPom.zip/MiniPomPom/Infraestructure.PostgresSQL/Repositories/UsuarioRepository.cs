﻿using Domain.Entities;
using Domain.Interfaces.Repositories;
using Infraestructure.PostgresSQL.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace Infraestructure.PostgresSQL.Repositories
{
    public class UsuarioRepository : BaseRepository<Usuario>, IUsuarioRepository
    {
        /// <inheritdoc />
        public new void Add(Usuario usuario)
        {
            db.Usuario.Add(usuario);
        }

        public void LoadCollection(Usuario usuario, Expression<Func<Usuario, IEnumerable<TipoRol>>> collection)
        {
            var usuarios_Roles = db.Usuario_Roles
                                    .Where(usu => usu.UsuarioId == usuario.Id)
                                    .Select(usu => usu.TipoRol)
                                    .ToList();
            usuario.SetTiposRoles(usuarios_Roles);
        }

        public Usuario GetById(Guid idUsuario)
        {
            var usuario = db.Usuario.FirstOrDefault(x => x.Id == idUsuario);

            if (usuario is null) return null;

            LoadCollection(usuario, e => e.Roles);

            return usuario;
        }

        public void AddRole(Guid idUsuario, string idRol)
        {
            db.Usuario_Roles.Add(new Usuario_Roles()
            {
                UsuarioId = idUsuario,
                TipoRolId = idRol
            });
        }

        public void RemoveRole(Guid idUsuario, string idRol)
        {
            var usuarios_roles = new Usuario_Roles { UsuarioId = idUsuario, TipoRolId = idRol };
            db.Usuario_Roles.Remove(usuarios_roles);
        }

        public Usuario GetByUser(string username)
        {
            var usuario = db.Usuario.FirstOrDefault(x => x.NombreUsuario == username);

            if (usuario is null) return null;

            LoadCollection(usuario, e => e.Roles);

            return usuario;
        }
        public bool ExistByUser(string username)
        {
            var usuario = db.Usuario.FirstOrDefault(x => x.NombreUsuario == username);
            if (usuario is null) return false;
            return true;
        }
    }
}
