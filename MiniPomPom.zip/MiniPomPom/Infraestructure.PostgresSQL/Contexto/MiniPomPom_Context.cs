﻿using Domain.Entities;
using Infraestructure.PostgresSQL.EntityConfig;
using Infraestructure.PostgresSQL.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace Infraestructure.PostgresSQL
{
    public class MiniPomPom_Context : DbContext
    {
        public MiniPomPom_Context() : base()
        {
            
        }
        public MiniPomPom_Context(DbContextOptions<MiniPomPom_Context> options) : base(options)
        {

        }
        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<TipoRol> TipoRol { get; set; }
        public DbSet<Usuario_Roles> Usuario_Roles { get; set; }

        public DbSet<Bitacora> Bitacora { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            // Conexion Sin Logger
            optionsBuilder.UseNpgsql(@"Server=35.226.71.135;Database=century-mau;Uid=postgres;Pwd=C3ntury2020");
            optionsBuilder.UseLazyLoadingProxies();
        }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new UsuarioConfiguration());
            modelBuilder.ApplyConfiguration(new TipoRolConfiguration());
            modelBuilder.ApplyConfiguration(new Usuario_RolesConfiguration());
            
            
            //modelBuilder.ApplyConfiguration(new EmpleadoConfiguration());
            //modelBuilder.ApplyConfiguration(new DocumentacionConfiguration());
            //modelBuilder.ApplyConfiguration(new TareaLaboralConfiguration());
            //modelBuilder.ApplyConfiguration(new TipoDocumentacionConfiguration());
            //modelBuilder.ApplyConfiguration(new EmpleadoTareaLaboralConfiguration());
            //modelBuilder.ApplyConfiguration(new TareaLaboralTipoDocumentacionConfiguration());
            //modelBuilder.ApplyConfiguration(new EmpresaConfiguration());
            //modelBuilder.ApplyConfiguration(new DomicilioEmpresaConfiguration());
            //modelBuilder.ApplyConfiguration(new ContactoConfiguration());
            //modelBuilder.Seed();
        }

        public override int SaveChanges()
        {
            //foreach (var entry in ChangeTracker.Entries().Where(entry => entry.Entity.GetType().GetProperty("FechaRegistro") != null))
            //{
            //    if (entry.State == EntityState.Added)
            //    {
            //        entry.Property("FechaRegistro").CurrentValue = DateTime.Now;
            //    }
            //    if (entry.State == EntityState.Modified)
            //    {
            //        entry.Property("FechaRegistro").IsModified = false;
            //    }
            //}

            return base.SaveChanges();
        }
    }
}
