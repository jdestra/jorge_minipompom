﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Core
{
    /// <summary>
    /// Represents that the implemented classes are domain entities.
    /// </summary>
    /// <typeparam name="TKey">The type of the entity key.</typeparam>
    public abstract class Entity<TId> : IEquatable<Entity<TId>>
        where TId : IEquatable<TId>
    {
        /// <summary>
        /// Gets or sets the entity key.
        /// </summary>
        /// <value>
        /// The entity key.
        /// </value>
        public virtual TId Id { get; set; }

        public override bool Equals(object other)
        {
            if (other is Entity<TId> entity)
            {
                return this.Equals(entity);
            }
            return base.Equals(other);
        }

        public virtual bool Equals(Entity<TId> other)
        {
            if (other is null)
            {
                return false;
            }
            return this.Id.Equals(other.Id);
        }
        public static bool operator ==(Entity<TId> x, Entity<TId> y)
        {
            return x.Equals(y);
        }

        public static bool operator !=(Entity<TId> x, Entity<TId> y)
        {
            return !(x == y);
        }

        public override int GetHashCode()
        {
            return (GetType().ToString() + this.Id).GetHashCode();
        }
    }
}
