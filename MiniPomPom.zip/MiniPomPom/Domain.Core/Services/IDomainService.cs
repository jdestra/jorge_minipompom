﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Core.Services
{
    /// Representa a todas las clases derivadas como Servicio del Dominio
    /// </summary>
    /// <seealso cref="System.IDisposable" />
    public interface IDomainService : IDisposable
    {

    }
}
