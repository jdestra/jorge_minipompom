﻿using System;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System.Collections.Generic;

namespace Domain.Core
{
    public class MiniPomPomError
    {
        [JsonProperty("codigo")]
        [JsonConverter(typeof(StringEnumConverter))]
        public TipoError Codigo { get; private set; }

        public string Mensaje { get; private set; }

        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public string Destino { get; private set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public IEnumerable<MiniPomPomError> Detalles { get; private set; }
        [JsonProperty(NullValueHandling = NullValueHandling.Ignore)]
        public MiniPomPomError InnerError { get; private set; }

        public MiniPomPomError(TipoError codigo, string mensaje, string destino, IEnumerable<MiniPomPomError> detalles = null, MiniPomPomError innerError = null)
        {
            Codigo = codigo;
            Mensaje = mensaje;
            Destino = destino;
            Detalles = detalles;
            InnerError = innerError;
        }

        /// <summary>
        /// Lista de errores posibles para un MiniPomPomError
        /// </summary>
        public enum TipoError
        {
            NoEncontrado,
            ErrorCommit,
            ValorIncorrecto,
            ErrorValidacion,
            NoPermitido,
            NoControlada
        }
    }
}
