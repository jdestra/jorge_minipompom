﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Core
{
    public class MiniPomPomException : Exception
    {
        public MiniPomPomError MiniPomPomError { get; private set; }

        public MiniPomPomException() { }

        public MiniPomPomException(MiniPomPomError miniPomPomError) : base(miniPomPomError.Mensaje)
        {
            MiniPomPomError = miniPomPomError;
        }

        public MiniPomPomException(MiniPomPomError miniPomPomError, Exception innerException)
            : base(miniPomPomError.Mensaje, innerException)
        {
            MiniPomPomError = miniPomPomError;
        }
    }
}
