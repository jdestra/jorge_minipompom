﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Application.ModelsDto
{
    public class UsuarioDTO
    {
        [JsonProperty("nombreUsuario")]
        public string NombreUsuario { get; set; }

        [JsonProperty("password")]
        public string Password { get; set; }

        [JsonProperty("activo")]
        public bool Activo { get; set; }

        [JsonProperty("personaId")]
        public Guid? PersonaId { get; set; }
    }
}
