﻿using AutoMapper;
using Domain.Entities;
//using Application.ModelsDto.Agreggates;

namespace Application
{
    public class AutoMapperMappingProfile : Profile
    {
        public AutoMapperMappingProfile()
        {
            //CreateMap<Usuario, UsuarioDTO>();
            //CreateMap<Usuario, UsuarioPutDTO>();
            //CreateMap<TipoRol, TipoRolDTO>();
        }
    }
}
