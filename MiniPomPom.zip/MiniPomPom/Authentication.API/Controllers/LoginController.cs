﻿//using Application.ModelsDto.Agreggates;
using Domain.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;

namespace Authentication.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : Controller
    {
        private readonly ILoginService _loginService;
        private readonly IConfiguration _config;
        

        public LoginController(ILoginService loginService, IConfiguration config)
        {
            _loginService = loginService;
            _config = config;
        }

        /// <summary>
        /// Autenticar Usuario
        /// </summary>
        /// <param name="usuario">nombre del usuario que se desea autenticar</param>
        /// <param name="password">password del usuario que se desea autenticar</param>
        /// <returns>token JWT</returns>
        /// <response code="200">Se autentico correctamente</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Error interno del servidor</response>
        [AllowAnonymous]
        [HttpPost]
        //[Route("")]
        [ProducesResponseType(200)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult Authenticate([FromQuery] string usuario, [FromQuery] string password)
        {
            var secretKey = _config.GetValue<string>("SecretKey");
            var timeExpiredToken = _config.GetValue<int>("TimeExpiredToken");
            string token = _loginService.Authenticate(usuario, password, secretKey,timeExpiredToken);
            return Ok(token);
        }

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Get()
        {
            return Ok("Service Ok");
        }
    }
}
