﻿using AutoMapper;
using Domain.Interfaces.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Security.Claims;
using Application.ModelsDto;

namespace Authentication.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : Controller
    {
        //private readonly IMapper _mapper;
        private readonly IUsuarioService _usuarioService;
        private readonly IConfiguration _config;

        public UsuariosController(IUsuarioService usuarioService, IConfiguration config)//, IMapper mapper
        {
            _usuarioService = usuarioService;
            _config = config;
            //_mapper = mapper;
        }
        /// <summary>
        /// Crear Usuario
        /// </summary>
        /// <param name="user">Objeto que recibe como parametros</param>
        /// <returns>Usuario creado en header location</returns>
        /// <response code="201">Usuario creado correctamente</response>
        /// <response code="403">Forbidden - El usuario no esta autorizado a acceder, o no tiene el rol GestionarRoles.</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Error interno del servidor</response>
        [Authorize(Roles = "GestionarRoles")]
        [HttpPost()]
        [ProducesResponseType(201)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        //public IActionResult Save([FromQuery] string nombreUsuario, [FromQuery] string password, [FromQuery] bool activo,[FromQuery]Guid? personaId)
        public IActionResult Save([FromBody] UsuarioDTO user)
        {
            var objusuario = _usuarioService.SaveUser(user.NombreUsuario, user.Password, user.Activo, user.PersonaId);
            return Created(new Uri($"{Request.Path}/{objusuario.Id}", UriKind.Relative), null);
        }

        /// <summary>
        /// Actualizar password Usuario
        /// </summary>
        /// <param name="newPassword">nueva password</param>
        /// <param name="oldPassword">antigua password</param>
        /// <returns>se actualizo el password correctamente</returns>
        /// <response code="200">Actualizo el password correctamente</response>
        /// <response code="403">Forbidden - El usuario no esta autorizado a acceder, o no tiene el rol GestionarRoles.</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Error interno del servidor</response>
        [Authorize(Roles = "GestionarRoles")]
        [HttpPut()]
        [Route("{idUsuario}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult UpdatePassword([FromQuery] string newPassword, [FromQuery] string oldPassword)
        {
            //var identity = HttpContext.User.Identity as ClaimsIdentity;
            var identityName = HttpContext.User.FindFirstValue(ClaimTypes.Name);
            _usuarioService.UpdatePassword(newPassword, oldPassword, identityName);
            return Ok();
        }

        /// <summary>
        /// Asignar rol Usuario
        /// </summary>
        /// <param name="idUsuario">id del usuario al que se asignara el rol</param>
        /// <param name="idRol">id de rol a asignar al usuario</param>
        /// <returns>estado de ejecucion</returns>
        /// <response code="200">El usuario asigno el rol correctamente</response>
        /// <response code="403">Forbidden - El usuario no esta autorizado a acceder, o no tiene el rol GestionarRoles.</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Error interno del servidor</response>
        [Authorize(Roles = "GestionarRoles")]
        [HttpPost()]
        [Route("{idUsuario}/roles/{idRol}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult AssignRole(Guid idUsuario, string idRol)
        {
            _usuarioService.AssignRole(idUsuario, idRol);
            return Ok();
        }

        /// <summary>
        /// Eliminar rol Usuario
        /// </summary>
        /// <param name="idUsuario">id del usuario al que se asignara el rol</param>
        /// <param name="idRol">id de rol a asignar al usuario</param>
        /// <returns>estado de ejecucion</returns>
        /// <response code="200">Se elimino el rol correctamente</response>
        /// <response code="403">Forbidden - El usuario no esta autorizado a acceder, o no tiene el rol GestionarRoles.</response>
        /// <response code="404">Not Found</response>
        /// <response code="500">Error interno del servidor</response>
        [Authorize(Roles = "GestionarRoles")]
        [HttpDelete()]
        [Route("{idUsuario}/roles/{idRol}")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult DeleteRole(Guid idUsuario, string idRol)
        {
            _usuarioService.DeleteRole(idUsuario, idRol);
            return Ok();
        }

        /// <summary>
        /// Busca y devuelve un usuario de la tabla usuarios en la base de datos
        /// </summary>
        /// <param name="idUsuario">IdUsuario a buscar en la base</param>
        /// <returns>Usuario</returns>
        /// <response code="200">Se encontro el usuario con exito</response>
        /// <response code="403">Forbidden - El usuario no esta autorizado a acceder, o no tiene el rol GestionarRoles.</response>
        /// <response code="404">No encontrado</response>
        /// <response code="500">Error interno del servidor</response>
        [HttpGet("{idUsuario}")]
        [Authorize(Roles = "GestionarRoles")]
        [ProducesResponseType(200)]
        [ProducesResponseType(403)]
        [ProducesResponseType(404)]
        [ProducesResponseType(500)]
        public IActionResult GetbyId(Guid idUsuario)
        {
            var usuario = _usuarioService.GetUserById(idUsuario);
            var usuarioAcotado = (
                nombreusuario: usuario.NombreUsuario,
                activo: usuario.Activo,
                personaid: usuario.PersonaId,
                roles: usuario.Roles
            );
            return Ok(usuarioAcotado);
        }
    }
}
