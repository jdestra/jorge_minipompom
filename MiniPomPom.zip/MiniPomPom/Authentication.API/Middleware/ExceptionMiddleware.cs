﻿using Domain.Core;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using System;
using System.Threading.Tasks;

namespace Authentication.API.Middleware
{
    public class ExceptionMiddleware
    {
        private readonly RequestDelegate next;
        public ExceptionMiddleware(RequestDelegate next)
        {
            this.next = next;
        }

        public async Task Invoke(HttpContext context)
        {
            try
            {
                await next(context);
            }
            catch (Exception ex)
            {
                await HandleExceptionAsync(context, ex);
            }
        }

        private static Task HandleExceptionAsync(HttpContext context, object ex)
        {
            MiniPomPomError miniPomPomError;
            var exception = (Exception)ex;

            if (ex.GetType() == typeof(MiniPomPomException))
            {
                miniPomPomError = ((MiniPomPomException)ex).MiniPomPomError;
            }
            else
            {
                miniPomPomError = new MiniPomPomError(MiniPomPomError.TipoError.NoControlada,
                    exception.Message,
                    string.Empty);
            }

            var result = JsonConvert.SerializeObject(new { error = miniPomPomError, stacktrace = exception.StackTrace });
            context.Response.ContentType = "application/json";
            context.Response.StatusCode = GetStatusCode(miniPomPomError);
            return context.Response.WriteAsync(result);
        }

        private static int GetStatusCode(MiniPomPomError miniPomPomError)
        {
            switch (miniPomPomError.Codigo)
            {
                case MiniPomPomError.TipoError.NoEncontrado:
                    return StatusCodes.Status404NotFound;
                default:
                    return StatusCodes.Status500InternalServerError;
            }
        }
    }
}
