﻿using Domain.Core;
using Domain.Core.Services;
using Domain.Entities;
using Domain.Interfaces.Repositories;
using Domain.Interfaces.Services;
using Domain.Shared;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Domain.Services
{
    public class LoginService : DomainService, ILoginService
    {
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly IBitacoraRepository _bitacoraRepository;
        public LoginService(IUsuarioRepository usuarioRepository, IBitacoraRepository bitacoraRepository)
        {
            _usuarioRepository = usuarioRepository;
            _bitacoraRepository = bitacoraRepository;
        }
        public string Authenticate(string username, string password, string secretKey,int timeExpiredToken)
        {
            var usuario = _usuarioRepository.GetByUser(username);
            if (usuario == null)
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.NoEncontrado,
                                            $"El usuario {username} no existe en la base de datos.",
                                            "Usuario"));

            if (!usuario.Activo)
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.ErrorValidacion, "Usuario Inactivo.", "Usuario", null));

            if (!HashHelper.CheckHash(password, usuario.HashPassword, usuario.Salt))
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.ErrorValidacion,
                                $"La contraseña del usuario {username} no coincide con la registrada en la base de datos.",
                                "Usuario"));

            var key = Encoding.ASCII.GetBytes(secretKey);
            var claims = new ClaimsIdentity();
            claims.AddClaim(new Claim(ClaimTypes.Name, username));

            foreach (var rol in usuario.Roles)
                claims.AddClaim(new Claim(ClaimTypes.Role, rol.Descripcion));
            if (usuario.PersonaId != null)
                claims.AddClaim(new Claim("PersonaId", usuario.PersonaId.ToString()));

            var tokenDescriptor = new SecurityTokenDescriptor
            {
                Subject = claims,

                Expires = DateTime.UtcNow.AddHours(timeExpiredToken),
                
                SigningCredentials = new SigningCredentials(new SymmetricSecurityKey(key), SecurityAlgorithms.HmacSha256Signature)
            };

            var tokenHandler = new JwtSecurityTokenHandler();
            var createdToken = tokenHandler.CreateToken(tokenDescriptor);

            _bitacoraRepository.AddBitacora(Bitacora.SetBitacora(usuario.Id, "Authenticate"));
            _bitacoraRepository.Commit();
            return tokenHandler.WriteToken(createdToken);     
        }
    }
}
