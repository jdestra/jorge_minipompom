﻿using Domain.Core;
using Domain.Core.Services;
using Domain.Entities;
using Domain.Interfaces.Repositories;
using Domain.Interfaces.Services;
using Domain.Shared;
using System;

namespace Domain.Services
{
    public class UsuarioService : DomainService, IUsuarioService
    {
        private readonly IUsuarioRepository _usuarioRepository;
        private readonly IBitacoraRepository _bitacoraRepository;
        public UsuarioService(IUsuarioRepository usuarioRepository,IBitacoraRepository bitacoraRepository)
        {
            _usuarioRepository = usuarioRepository;
            _bitacoraRepository = bitacoraRepository;
        }

        public Usuario SaveUser(string nombreUsuario, string password, bool activo,Guid? personaId)
        {
            if (_usuarioRepository.ExistByUser(nombreUsuario))
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.NoEncontrado,
                                            $"No se puede crear el usuario {nombreUsuario}. Ya existe en la base de datos.",
                                            "Usuario"));

            var objUsuario = new Usuario();
            objUsuario.SetNombreUsuario(nombreUsuario);
            objUsuario.SetActivo(activo);
            if (personaId != null)
                objUsuario.SetPersonaId(personaId);
            HashedPassword obj = HashHelper.Hash(password);
            objUsuario.SetHashPassword(obj.Password);
            objUsuario.SetSalt(obj.Salt);
            _usuarioRepository.Add(objUsuario);
            _usuarioRepository.Commit();
            
            _bitacoraRepository.AddBitacora(Bitacora.SetBitacora(objUsuario.Id, "SaveUser"));
            _bitacoraRepository.Commit();
            return objUsuario;
        }

      
        public void AssignRole(Guid idUsuario,string idRol)
        {
            _usuarioRepository.AddRole(idUsuario, idRol);
            _usuarioRepository.Commit();

            _bitacoraRepository.AddBitacora(Bitacora.SetBitacora(idUsuario, "AssignRole"));
            _bitacoraRepository.Commit();
        }

        public void DeleteRole(Guid idUsuario, string idRol)
        {
            _usuarioRepository.RemoveRole(idUsuario, idRol);
            _usuarioRepository.Commit();

            _bitacoraRepository.AddBitacora(Bitacora.SetBitacora(idUsuario, "DeleteRole"));
            _bitacoraRepository.Commit();
        }

        public void UpdatePassword(string newPassword,string oldPassword, string nombreUsuario)
        {
            if (!_usuarioRepository.ExistByUser(nombreUsuario))
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.NoEncontrado,
                                            $"El usuario {nombreUsuario} no existe en la base de datos.",
                                            "Usuario"));

            var usuario = _usuarioRepository.GetByUser(nombreUsuario);
            if (!HashHelper.CheckHash(oldPassword, usuario.HashPassword, usuario.Salt))
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.ErrorValidacion,
                                            $"La contraseña anterior del usuario {nombreUsuario} no coincide con la registrada en la base de datos.",
                                            "Usuario"));

            HashedPassword obj = HashHelper.Hash(newPassword);
            usuario.SetHashPassword(obj.Password);
            usuario.SetSalt(obj.Salt);

            _usuarioRepository.Update(usuario);
            _usuarioRepository.Commit();

            _bitacoraRepository.AddBitacora(Bitacora.SetBitacora(usuario.Id, "DeleteRole"));
            _bitacoraRepository.Commit();
        }

        public Usuario GetUserById(Guid idUsuario)
        {
            var usuario = _usuarioRepository.GetById(idUsuario);
            if (usuario == null)
                throw new MiniPomPomException(new MiniPomPomError(MiniPomPomError.TipoError.NoEncontrado,
                                            $"El usuario no existe en la base de datos.",
                                            "Usuario"));
            return usuario;
        }
    }
}
