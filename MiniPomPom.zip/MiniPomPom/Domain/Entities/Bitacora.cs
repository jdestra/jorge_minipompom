﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities
{
    public class Bitacora
    {
        //UsuarioId, Fecha, Hora, AccionRealizada
        public int Id { get; set; }
        public Guid UsuarioId { get; private set; }
        public DateTime Fecha { get; private set; }
        public string AccionRealizada { get;private set; }
        public void SetUsuarioId(Guid usuarioId) => UsuarioId = usuarioId;
        public void SetFecha(DateTime fecha) => Fecha = fecha;
        public void SetAccionRealizada(string accionRealizada) => AccionRealizada = accionRealizada;

        public static Bitacora SetBitacora(Guid idUsuario,string accionRealizada)
        {
            Bitacora objBitacora = new Bitacora();
            objBitacora.SetUsuarioId(idUsuario);
            objBitacora.SetFecha(System.DateTime.Now);
            objBitacora.SetAccionRealizada(accionRealizada);
            return objBitacora;
        }

    }
}
