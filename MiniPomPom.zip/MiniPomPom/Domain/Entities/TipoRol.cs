﻿using Domain.Core;

namespace Domain.Entities
{
    public class TipoRol : EntityTipo<string>
    {

        public TipoRol() : base()
        {

        }

        public TipoRol(string id, string descripcion) : base(id, descripcion)
        {

        }
    }
}
