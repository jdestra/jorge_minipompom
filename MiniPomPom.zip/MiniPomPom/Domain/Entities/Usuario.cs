﻿using Domain.Core;
using System;
using System.Collections.Generic;

namespace Domain.Entities
{
    public class Usuario : Entity<Guid>, IAggregateRoot
    {
        public string NombreUsuario { get; private set; }
        public string HashPassword { get; private set; }
        public string Salt { get; private set; }
        public bool Activo { get; private set; }
        public Guid? PersonaId { get; private set; }
        public virtual IEnumerable<TipoRol> Roles { get; private set; }
        public void SetTiposRoles(IEnumerable<TipoRol> roles) => Roles = roles;
        public Usuario()
        {

        }

        public void SetHashPassword(string hashPassword) => HashPassword = hashPassword;
        public void SetNombreUsuario(string nombreUsuario) => NombreUsuario = nombreUsuario;
        public void SetActivo(bool activo) => Activo = activo;
        public void SetSalt(string salt) => Salt = salt;
        public void SetPersonaId(Guid? personaId) => PersonaId = personaId;
    }
}
