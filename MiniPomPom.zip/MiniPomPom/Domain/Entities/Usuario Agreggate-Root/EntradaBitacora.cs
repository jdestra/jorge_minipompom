﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Entities.Empleado_Agreggate_Root
{
    public class EntradaBitacora
    {
    }
}
