﻿using Domain.Core.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.Repositories
{
    public interface IBitacoraRepository: IRepositoryBase<Bitacora>
    {
        void AddBitacora(Bitacora bitacora);
    }
}
