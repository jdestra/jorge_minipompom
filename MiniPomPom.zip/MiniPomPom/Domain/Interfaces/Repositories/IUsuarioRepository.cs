﻿using Domain.Core.Repositories;
using Domain.Entities;
using System;

namespace Domain.Interfaces.Repositories
{
    public interface IUsuarioRepository : IRepositoryBase<Usuario>
    {
        void AddRole(Guid id,string idRol);
        Usuario GetById(Guid id);
        void RemoveRole(Guid id, string idRol);
        Usuario GetByUser(string username);
        bool ExistByUser(string username);
    }
}
