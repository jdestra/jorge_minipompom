﻿using Domain.Core.Repositories;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.Repositories
{
    interface ILoginRepository : IRepositoryBase<Usuario>
    {
    }
}
