﻿using Domain.Core.Services;
using Domain.Entities;
using System;

namespace Domain.Interfaces.Services
{
    public interface IUsuarioService : IDomainService
    {
        Usuario SaveUser(string usuario,string password,bool activo,Guid? personaId);
        void UpdatePassword(string newPassword,string oldPassword,string nombreUsuario);
        void AssignRole(Guid idUsuario, string idRol);  
        void DeleteRole(Guid idUsuario, string idRol);
        Usuario GetUserById(Guid idusuario);
    }
}
