﻿using Domain.Core.Repositories;
using Domain.Core.Services;
using Domain.Entities;
using System;
using System.Collections.Generic;
using System.Text;

namespace Domain.Interfaces.Services
{
    public interface ILoginService : IDomainService
    {
        string Authenticate(string username, string password, string secretKey,int timeExpiredToken);
    }
}
